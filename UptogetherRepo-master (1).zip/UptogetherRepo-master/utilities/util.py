import time, os, random
from enum import Enum
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

class Utils:
    
    SHORT_WAIT_TIME = 0.5
    MEDIUM_WAIT_TIME = 1
    LONG_WAIT_TIME = 2
    DEFAULT_WAIT_TIME = 40

    def __init__(self, driver, device):
        self.driver = driver
        self.device = device
        self.initiate_wait(device)

    def initiate_wait(self, device):
        if device == "ios":
            self.SHORT_WAIT_TIME = 0.75
            self.MEDIUM_WAIT_TIME = 1.5
            self.LONG_WAIT_TIME = 3
        elif device == 'android':
            self.SHORT_WAIT_TIME = 2
            self.MEDIUM_WAIT_TIME = 3
            self.LONG_WAIT_TIME = 6

    def find_elment_method(self, locatorType):
        if locatorType == Locators.ID: 
            return self.driver.find_element_by_id
        elif locatorType == Locators.NAME:
            return self.driver.find_element_by_name
        elif locatorType == Locators.XPATH:
            return self.driver.find_element_by_xpath
        elif locatorType == Locators.CSS_SELECTOR:
            return self.driver.find_element_by_css_selector
        elif locatorType == Locators.CLASS_NAME:
            return self.driver.find_element_by_class_name
        elif locatorType == Locators.TAG_NAME:
            return self.driver.find_element_by_tag_name
        elif locatorType == Locators.LINK_TEXT:
            return self.driver.find_element_by_link_text
        elif locatorType == Locators.PARTIAL_LINK_TEXT:
            return self.driver.find_element_by_partial_link_text

    def find_elements_method(self, locatorType):
        if locatorType == Locators.ID: 
            return self.driver.find_elements_by_id
        elif locatorType == Locators.NAME:
            return self.driver.find_elements_by_name
        elif locatorType == Locators.XPATH:
            return self.driver.find_elements_by_xpath
        elif locatorType == Locators.CSS_SELECTOR:
            return self.driver.find_elements_by_css_selector
        elif locatorType == Locators.CLASS_NAME:
            return self.driver.find_elements_by_class_name
        elif locatorType == Locators.TAG_NAME:
            return self.driver.find_elements_by_tag_name
        elif locatorType == Locators.LINK_TEXT:
            return self.driver.find_elements_by_link_text
        elif locatorType == Locators.PARTIAL_LINK_TEXT:
            return self.driver.find_elements_by_partial_link_text

    def find_by(self, locatorType):
        if locatorType == Locators.ID: 
            return By.ID
        elif locatorType == Locators.NAME:
            return By.NAME
        elif locatorType == Locators.XPATH:
            return By.XPATH
        elif locatorType == Locators.CSS_SELECTOR:
            return By.CSS_SELECTOR
        elif locatorType == Locators.CLASS_NAME:
            return By.CLASS_NAME
        elif locatorType == Locators.TAG_NAME:
            return By.TAG_NAME
        elif locatorType == Locators.LINK_TEXT:
            return By.LINK_TEXT
        elif locatorType == Locators.PARTIAL_LINK_TEXT:
            return By.PARTIAL_LINK_TEXT

    def find_elements(self, locator, locatorType):
        self.wait_for_element(locator, locatorType)
        find_elements = self.find_elements_method(locatorType)
        all_elements = find_elements(locator)
        return all_elements

    def click(self, locator, locatorType, max_time = DEFAULT_WAIT_TIME):
        self.wait_for_element_to_be_clickable(locator, locatorType, max_time)
        find_element = self.find_elment_method(locatorType)
        ele = find_element(locator)
        ele.click()
        time.sleep(self.SHORT_WAIT_TIME)
    
    def send_keys(self, locator, textValue, locatorType, need_clear=True):
        self.wait_for_element(locator, locatorType)
        find_element = self.find_elment_method(locatorType)
        ele = find_element(locator)
        if need_clear == True:
            ele.clear()
        self.driver.execute_script("arguments[0].value='';", ele)
        ele.send_keys(textValue)

    def get_dropdown_selected_value(self, select_locator, locatorType):
        find_element = self.find_elment_method(locatorType)
        select = Select(find_element(select_locator))
        selected_option = select.first_selected_option
        return selected_option.text.strip()

    def set_dropdown_by_value(self, select_locator, option_value, locatorType, setting_iteration=1):
        find_element = self.find_elment_method(locatorType)
        select = Select(find_element(select_locator))
        options = select.options
        ddown_index = -1
        is_matched = False
        for option in options:
            curr_option_value = option.text.strip()
            ddown_index = ddown_index + 1
            if curr_option_value == option_value:
                is_matched = True
                break
        if is_matched == False:
            raise Exception("None of the option value is matched in the dropdown")
        for i in range(setting_iteration):
            select.select_by_index(ddown_index)
            time.sleep(self.LONG_WAIT_TIME * 3)

    def get_checkbox_selected_value(self, all_checkbox_locator, locatorType):
        find_elements = self.find_elements_method(locatorType)
        all_checkboxes = find_elements(all_checkbox_locator)
        for checkbox in all_checkboxes:
            check_ele = checkbox.find_element_by_xpath("./span[@class='check']")
            if check_ele.value_of_css_property("background-image") != "none":
                return checkbox.find_element_by_xpath("./span[@class='control-label']").text.strip()
        return None

    def set_checkbox_by_value(self, all_checkbox_locator, checkbox_value, locatorType):
        find_elements = self.find_elements_method(locatorType)
        all_checkboxes = find_elements(all_checkbox_locator)
        for checkbox in all_checkboxes:
            check_ele = checkbox.find_element_by_xpath("./span[@class='check']")
            if check_ele.value_of_css_property("background-image") != "none" :
                check_ele.click()
                break
        time.sleep(self.SHORT_WAIT_TIME)   
        all_checkboxes = find_elements(all_checkbox_locator)
        for checkbox in all_checkboxes:
            check_ele = checkbox.find_element_by_xpath("./span[@class='control-label']")
            if check_ele.text.strip() == checkbox_value:
                if checkbox.find_element_by_xpath("./span[@class='check']").value_of_css_property("background-image") == "none" :
                    check_ele.click()

    def get_text(self, locator, locatorType):
        self.wait_for_element(locator, locatorType)
        find_element = self.find_elment_method(locatorType)
        ele = find_element(locator)
        return ele.text

    def get_attribute(self, locator, locatorType, attribute_name):
        self.wait_for_element(locator, locatorType)
        find_element = self.find_elment_method(locatorType)
        ele = find_element(locator)
        return ele.get_attribute(attribute_name)
        
    def is_displayed(self, locator, locatorType):
        self.wait_for_element(locator, locatorType)
        find_element = self.find_elment_method(locatorType)
        ele = find_element(locator)
        return ele.is_displayed()

    def is_element_present(self, locator, locatorType, max_time = DEFAULT_WAIT_TIME):
        try:
            self.wait_for_element(locator, locatorType, max_time)
            find_element = self.find_elment_method(locatorType)
            ele = find_element(locator)
            return ele.is_displayed()
        except:
            return False
        
    def wait_for_element(self, locator, locatorType, max_time = DEFAULT_WAIT_TIME):
        wait = WebDriverWait(self.driver, max_time)
        wait.until(EC.presence_of_element_located((self.find_by(locatorType), locator)))
        time.sleep(self.SHORT_WAIT_TIME)
    
    def wait_for_element_to_be_clickable(self, locator, locatorType, max_time = DEFAULT_WAIT_TIME):
        wait = WebDriverWait(self.driver, max_time)
        wait.until(EC.element_to_be_clickable((self.find_by(locatorType), locator)))
        time.sleep(self.MEDIUM_WAIT_TIME)

    def wait_till_spin_loader(self, max_time = DEFAULT_WAIT_TIME):
        try:
            wait = WebDriverWait(self.driver, max_time)
            wait.until(EC.invisibility_of_element_located((self.find_by(Locators.XPATH), "//div[contains(@class, 'animate-spin')]")))
            time.sleep(self.SHORT_WAIT_TIME)
        except:
            pass

    def wait_till_disappear(self, locator, locatorType, max_time = DEFAULT_WAIT_TIME):
        try:
            wait = WebDriverWait(self.driver, max_time)
            wait.until(EC.invisibility_of_element_located((self.find_by(locatorType), locator)))
            time.sleep(self.SHORT_WAIT_TIME)
        except:
            pass

    # def get_random_string(self, prefixstring):
    #     randNum = random.randint(1000,9999)
    #     randStr = prefixstring + str(randNum)
    #     return randStr
    
    def mouse_hover(self, locator, locatorType):
        time.sleep(self.SHORT_WAIT_TIME)
        actions = ActionChains(self.driver)
        find_element = self.find_elment_method(locatorType)
        ele = find_element(locator)
        actions.move_to_element(ele).perform()
        time.sleep(self.MEDIUM_WAIT_TIME)     

    def js_send_keys(self, locator, textValue, locatorType):
        time.sleep(self.SHORT_WAIT_TIME)
        find_element = self.find_elment_method(locatorType)
        ele = find_element(locator)
        self.driver.execute_script("arguments[0].setAttribute('value', '" + textValue +"');", ele)
        time.sleep(self.MEDIUM_WAIT_TIME)

    def js_innerHTML(self, locator, textValue, locatorType):
        time.sleep(self.SHORT_WAIT_TIME)
        find_element = self.find_elment_method(locatorType)
        ele = find_element(locator)
        self.driver.execute_script("arguments[0].innerHTML = '" + textValue + "';", ele)
        time.sleep(self.MEDIUM_WAIT_TIME)

    def js_flex_display(self, locator, locatorType):
        time.sleep(self.SHORT_WAIT_TIME)
        find_element = self.find_elment_method(locatorType)
        ele = find_element(locator)
        self.driver.execute_script("arguments[0].style.display = 'flex';", ele)
        time.sleep(self.MEDIUM_WAIT_TIME)

    def js_click(self, locator, locatorType):
        time.sleep(self.SHORT_WAIT_TIME)
        # self.wait_for_element(locator, locatorType)
        find_element = self.find_elment_method(locatorType)
        ele = find_element(locator)
        self.driver.execute_script("arguments[0].click();", ele)
        time.sleep(self.MEDIUM_WAIT_TIME)

    def js_enable_button(self, locator, locatorType):
        time.sleep(self.SHORT_WAIT_TIME)
        # self.wait_for_element(locator, locatorType)
        find_element = self.find_elment_method(locatorType)
        ele = find_element(locator)
        self.driver.execute_script("arguments[0].removeAttribute('disabled','disabled');", ele)
        time.sleep(self.MEDIUM_WAIT_TIME)

    def bring_to_top(self, locator, locatorType):
        time.sleep(self.SHORT_WAIT_TIME)
        find_element = self.find_elment_method(locatorType)
        ele = find_element(locator)
        self.driver.execute_script("arguments[0].scrollIntoView();", ele )
        time.sleep(self.SHORT_WAIT_TIME)
        self.driver.execute_script("window.scrollBy(0,-60)","" )
        time.sleep(self.MEDIUM_WAIT_TIME)

    def scroll_to_top(self):
        if self.device != "web":
            self.driver.execute_script("window.scrollBy(0,-1000)","" )
            time.sleep(self.SHORT_WAIT_TIME)

    def upload_file(self, fileName, locator, locatorType):
        find_element = self.find_elment_method(locatorType)
        ele = find_element(locator)
        file_relative_path = 'resource/'+fileName
        file_abs_path = os.path.abspath(file_relative_path)
        print(file_abs_path)
        ele.send_keys(file_abs_path)
    
    def open_new_tab_and_set_focus(self, url):
        self.driver.execute_script('''window.open("about:blank");''')
        previous_window = self.driver.current_window_handle
        all_windows = self.driver.window_handles
        for window in all_windows:
            if(window != previous_window):
                self.driver.switch_to.window(window)
                break
        time.sleep(1)
        self.driver.get(url)
        time.sleep(1)

    def switch_to_other_window(self):
        previous_window = self.driver.current_window_handle
        all_windows = self.driver.window_handles
        for window in all_windows:
            if(window != previous_window):
                self.driver.switch_to.window(window)
                break
        time.sleep(1)

        
class Locators(Enum):
    XPATH = "XPATH"
    CSS_SELECTOR = "CSS_SELECTOR"
    ID = "id"
    CLASS_NAME = "CLASS_NAME"
    NAME = "NAME"
    TAG_NAME = "TAG_NAME"
    LINK_TEXT = "LINK_TEXT"
    PARTIAL_LINK_TEXT = "PARTIAL_LINK_TEXT"

class Data:
    global_dict = {}

    def get_random_string(self, prefixstring):
        randNum = random.randint(1000,9999)
        randStr = prefixstring + str(randNum)
        return randStr

    def set_unique_name(self, name):
        self.global_dict[name] = self.get_random_string(name)
        return self.global_dict.get(name)

    def get_unique_name(self, name):
        if self.global_dict.get(name) == None:
            return name
        else:
            return self.global_dict.get(name)
