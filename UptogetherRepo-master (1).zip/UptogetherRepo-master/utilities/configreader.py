import configparser
import os
config = configparser.RawConfigParser()
config_path = os.getcwd() + os.sep + 'config.ini'
config.read(config_path)
class ReadConfig:
    @staticmethod
    def get_dev_url():
        return config.get('develop', 'url')
    
    @staticmethod
    def get_dev_domain():
        return config.get('develop', 'domain')
    
    @staticmethod
    def get_dev_auth_token():
        return config.get('develop', 'auth_token')
    
    @staticmethod
    def get_dev_refresh_token():
        return config.get('develop', 'refresh_token')

    @staticmethod
    def get_dev_username():
        return config.get('develop', 'username')
    
    @staticmethod
    def get_dev_password():
        return config.get('develop', 'password')

    @staticmethod
    def get_qa_url():
        return config.get('qa', 'url')
    
    @staticmethod
    def get_qa_domain():
        return config.get('qa', 'domain')
    
    @staticmethod
    def get_qa_auth_token():
        return config.get('qa', 'auth_token')
    
    @staticmethod
    def get_qa_refresh_token():
        return config.get('qa', 'refresh_token')

    @staticmethod
    def get_qa_username():
        return config.get('qa', 'username')
    
    @staticmethod
    def get_qa_password():
        return config.get('qa', 'password')

    @staticmethod
    def get_prod_url():
        return config.get('prod', 'url')
    
    @staticmethod
    def get_prod_domain():
        return config.get('prod', 'domain')
    
    @staticmethod
    def get_prod_auth_token():
        return config.get('prod', 'auth_token')
    
    @staticmethod
    def get_prod_refresh_token():
        return config.get('prod', 'refresh_token')

    @staticmethod
    def get_prod_username():
        return config.get('prod', 'username')
    
    @staticmethod
    def get_prod_password():
        return config.get('prod', 'password')

    @staticmethod
    def get_dev_tic_url():
        return config.get('develop_tic', 'url')

    @staticmethod
    def get_dev_tic_domain():
        return config.get('develop_tic', 'domain')

    @staticmethod
    def get_dev_tic_auth_token():
        return config.get('develop_tic', 'auth_token')

    @staticmethod
    def get_dev_tic_refresh_token():
        return config.get('develop_tic', 'refresh_token')

    @staticmethod
    def get_dev_tic_username():
        return config.get('develop_tic', 'username')

    @staticmethod
    def get_dev_tic_password():
        return config.get('develop_tic', 'password')