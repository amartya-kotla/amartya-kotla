from utilities.util import Locators
from utilities.util import Utils
from utilities.util import Data
import time

class ProfilePage:
    profile_header_xpath = "//span[text()='Profile']"
    basic_infomation_xpath = "//a[contains(@href,'/settings/profile/basic')]"
    basic_information_header_xpath = "//a[contains(@href,'/settings/profile/basic')]/span"
    language_setting_ddown_xpath = "//select[contains(@id, 'language_preference')]"
    save_button_xpath = "//button[contains(text(), 'save')] | //button[contains(text(), 'guardar')]"
    profile_updated_header_xpath = "//p[text()='Profile Updated']"
    ok_button_xpath = "//button[contains(text(), 'Ok')]"
    first_name_xpath = "//input[contains(@id,'first_name')]"
    last_name_xpath = "//input[contains(@id,'last_name')]"
    gender_ddown_xpath = "//select[contains(@id,'gender')]"
    date_of_birth_xpath = "//input[contains(@id,'dob')]"
    ethnicity_xpath = "//input[contains(@id,'ethnicity')]"
    all_races_xpath = "//label[contains(@for,'race')]/following-sibling::div/label"
    household_infomation_xpath = "//a[contains(@href,'/settings/profile/household')]"
    household_members_xpath = "//h3[contains(text(), 'household members')]/following-sibling::div/a[contains(@href,'household')]"
    household_member_names_xpath = "//h3[contains(text(), 'household members')]/following-sibling::div/a[contains(@href,'household')]/div[1]"
    add_member_button_xpath = "//a[contains(@href,'/household/create')]"
    first_name_id = "id_firstName"
    last_name_id = "id_lastName"
    relationship_ddown_id = "id_relationshipType"
    dob_id = "id_dob"
    household_member_param_fname_xpath = "//a[contains(@href,'/household')]/div[contains(text(), 'FNAME')]"
    delete_button_xpath = "//button[contains(text(), 'delete')]"
    delete_conformation_button_xpath = "//button[contains(text(), 'Yes, Delete Member')] | //div[contains(text(), 'Yes, Delete Member')]"
    delete_household_success_message_xpath = "//p[text()='Household member has been removed!']"
    close_button_xpath = "//button[text()='Close']"
    edit_household_success_message_xpath = "//p[text()='Household member information saved successfully!']"

    def __init__(self, driver, device):
        self.driver = driver
        self.device = device
        self.utils = Utils(driver, device)
        self.data = Data()
        
    def is_profile_page_displayed(self):
        self.utils.wait_for_element(self.profile_header_xpath, Locators.XPATH)
        return self.utils.is_displayed(self.profile_header_xpath, Locators.XPATH)
    
    def open_basic_information(self):
        self.utils.click(self.basic_infomation_xpath, Locators.XPATH)

    def set_language(self, language_name):
        self.utils.set_dropdown_by_value(self.language_setting_ddown_xpath, language_name, Locators.XPATH, 2)
    
    def save_page(self):
        self.utils.click(self.save_button_xpath, Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def confirm_profile_updated(self):
        self.utils.wait_for_element(self.profile_updated_header_xpath, Locators.XPATH)
        self.utils.click(self.ok_button_xpath, Locators.XPATH)

    def get_information_basic_header_name(self):
        return self.utils.get_text(self.basic_information_header_xpath, Locators.XPATH)

    def get_first_name(self):
        return self.utils.get_attribute(self.first_name_xpath, Locators.XPATH, "value")

    def set_first_name(self, first_name):
        self.utils.send_keys(self.first_name_xpath, first_name, Locators.XPATH)

    def get_last_name(self):
        return self.utils.get_attribute(self.last_name_xpath, Locators.XPATH, "value")

    def set_last_name(self, last_name):
        self.utils.send_keys(self.last_name_xpath, last_name, Locators.XPATH)

    def get_gender(self):
        return self.utils.get_dropdown_selected_value(self.gender_ddown_xpath, Locators.XPATH)

    def set_gender(self, gender):
        self.utils.set_dropdown_by_value(self.gender_ddown_xpath, gender, Locators.XPATH, 2)

    def get_date_of_birth(self):
        return self.utils.get_attribute(self.date_of_birth_xpath, Locators.XPATH, "value")

    def set_date_of_birth(self, date_of_birth):
        self.utils.send_keys(self.date_of_birth_xpath, date_of_birth, Locators.XPATH)

    def get_ethnicity(self):
        return self.utils.get_attribute(self.ethnicity_xpath, Locators.XPATH, "value")

    def set_ethnicity(self, ethnicity):
        self.utils.send_keys(self.ethnicity_xpath, ethnicity, Locators.XPATH)

    def get_race(self):
        return self.utils.get_checkbox_selected_value(self.all_races_xpath, Locators.XPATH)

    def set_race(self, race):
        self.utils.set_checkbox_by_value(self.all_races_xpath, race, Locators.XPATH)

    def open_household_information(self):
        self.utils.click(self.household_infomation_xpath, Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def get_household_members(self):
        return len(self.utils.find_elements(self.household_members_xpath,Locators.XPATH))

    def get_household_member_first_names(self):
        all_names_ele = self.utils.find_elements(self.household_member_names_xpath, Locators.XPATH)
        all_first_names = []
        for name_ele in all_names_ele:
            full_name = name_ele.text.strip()
            all_first_names.append(full_name.split(" ")[0])
        return all_first_names

    def add_household_member(self):
        self.utils.click(self.add_member_button_xpath, Locators.XPATH)

    def set_household_first_name(self, fname):
        self.utils.send_keys(self.first_name_id, self.data.set_unique_name(fname), Locators.ID)

    def set_household_last_name(self, lname):
        self.utils.send_keys(self.last_name_id, self.data.set_unique_name(lname), Locators.ID)

    def set_household_relationship(self, relationship):
        self.utils.set_dropdown_by_value(self.relationship_ddown_id, relationship, Locators.ID)

    def set_household_dob(self, dob):
        self.utils.send_keys(self.dob_id, dob, Locators.ID)
    
    def check_presence_of_household_fname(self, fname):
        unique_fname = self.data.get_unique_name(fname)
        all_fnames = self.get_household_member_first_names()
        return unique_fname in all_fnames
        
    def open_household_member_with_fname(self, fname):
        self.utils.click(self.household_member_param_fname_xpath.replace("FNAME",self.data.get_unique_name(fname)), Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def delete_household_member(self):
        self.utils.click(self.delete_button_xpath, Locators.XPATH)
        
    def delete_confirmation_household_member(self):
        self.utils.click(self.delete_conformation_button_xpath, Locators.XPATH)

    def check_delete_household_confirmation_message(self):
        return self.utils.is_displayed(self.delete_household_success_message_xpath, Locators.XPATH)
    
    def close_confirmation_message(self):
        self.utils.click(self.close_button_xpath, Locators.XPATH)
        self.utils.wait_till_spin_loader()

    def check_edit_household_confirmation_message(self):
        return self.utils.is_displayed(self.edit_household_success_message_xpath, Locators.XPATH)

    def verify_first_name_of_household(self, fname):
        assert self.data.get_unique_name(fname) == self.utils.get_attribute(self.first_name_id, Locators.ID, "value")

    def verify_last_name_of_household(self, lname):
        assert self.data.get_unique_name(lname) == self.utils.get_attribute(self.last_name_id, Locators.ID, "value")

    def verify_relationship_of_household(self, relationship):
        assert relationship == self.utils.get_dropdown_selected_value(self.relationship_ddown_id, Locators.ID)

    def verify_dob_of_household(self, dob):
        assert dob == self.utils.get_attribute(self.dob_id, Locators.ID, "value")