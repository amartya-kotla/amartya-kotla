from utilities.util import Locators
from utilities.util import Utils
import time

class FinancialsPage:
    financials_header_xpath = "//div[@class='title'][text()='Financials']"
    
    def __init__(self, driver, device):
        self.driver = driver
        self.device = device
        self.utils = Utils(driver, device)
        
    def is_profile_page_displayed(self):
        self.utils.wait_for_element(self.financials_header_xpath, Locators.XPATH)
        return self.utils.is_displayed(self.financials_header_xpath, Locators.XPATH)
    
    