from utilities.util import Locators
from utilities.util import Utils
from utilities.util import Data
import time


class TicPage:
    tic_header_xpath = "//div[text()='Trust and Invest Collaborative']"
    apply_now_xpath = "//button[@id='button-apply']"
    view_applications_xpath = "//button[contains(text(),'View Applications')]"

    def __init__(self, driver, device):
        self.driver = driver
        self.device = device
        self.utils = Utils(driver, device)
        self.data = Data()

    def is_tic_page_displayed(self):
        self.utils.wait_for_element(self.tic_header_xpath, Locators.XPATH)
        return self.utils.is_displayed(self.tic_header_xpath, Locators.XPATH)

    def apply_now(self):
        self.utils.click(self.apply_now_xpath, Locators.XPATH)

    def is_view_applications_displayed(self):
        return self.utils.is_element_present(self.view_applications_xpath, Locators.XPATH)