from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
import os, json
from datetime import datetime
import pytz
from behave.contrib.scenario_autoretry import patch_scenario_with_autoretry

CONFIG_FILE = os.environ['CONFIG_FILE'] if 'CONFIG_FILE' in os.environ else 'config/local_web.json'
TASK_ID = int(os.environ['TASK_ID']) if 'TASK_ID' in os.environ else 0

with open(CONFIG_FILE) as data_file:
    CONFIG = json.load(data_file)


LT_USERNAME = os.environ['LT_USERNAME'] if 'LT_USERNAME' in os.environ else CONFIG['user']
LT_ACCESS_KEY = os.environ['LT_ACCESS_KEY'] if 'LT_ACCESS_KEY' in os.environ else CONFIG['key']


def before_feature(context, feature):
    if 'local' not in LT_USERNAME:
        value = CONFIG.get('isBuildSet', False)
        if value == False:
            UTC = pytz.utc
            utc_dt = datetime.now(UTC)
            eastern = pytz.timezone('US/Eastern')
            loc_dt = utc_dt.astimezone(eastern)
            us_time_str = loc_dt.strftime("_%H_%M")
            CONFIG['isBuildSet'] = True
            SUITE_NAME = os.environ['SUITE_NAME']
            if SUITE_NAME == 'CONFIG_BUILD':
                SUITE_NAME = CONFIG["capabilities"]["build"]
            CONFIG["capabilities"]["build"] = SUITE_NAME + us_time_str
        
def before_scenario(context, scenario):
    if LT_USERNAME == 'local_web':
        context.browser = webdriver.Chrome(ChromeDriverManager().install())
        context.browser.implicitly_wait(10)
    elif LT_USERNAME == 'local_android':
        desired_capabilities = CONFIG['environments'][0]
        for key in CONFIG["capabilities"]:
            if key not in desired_capabilities:
                desired_capabilities[key] = CONFIG["capabilities"][key]
        context.browser = webdriver.Remote(
            desired_capabilities=desired_capabilities,
            command_executor="http://%s:%s/wd/hub" % ("0.0.0.0", 4723)
        )
        context.browser.implicitly_wait(10)
    elif LT_USERNAME == 'local_ios':
        desired_capabilities = CONFIG['environments'][0]
        for key in CONFIG["capabilities"]:
            if key not in desired_capabilities:
                desired_capabilities[key] = CONFIG["capabilities"][key]
        context.browser = webdriver.Remote(
            desired_capabilities=desired_capabilities,
            command_executor="http://%s:%s/wd/hub" % ("0.0.0.0", 4723)
        )
    else:
        desired_capabilities = CONFIG['environments'][TASK_ID]
        for key in CONFIG["capabilities"]:
            if key not in desired_capabilities:
                desired_capabilities[key] = CONFIG["capabilities"][key]
        desired_capabilities["name"] = context.scenario.name
        context.browser = webdriver.Remote(
            desired_capabilities=desired_capabilities,
            command_executor="http://%s:%s@hub.lambdatest.com/wd/hub" % (LT_USERNAME, LT_ACCESS_KEY)
    )
def before_step(context, step):
    context.step = step

def after_step(context, step):
    if 'local' not in LT_USERNAME:
        if step.status == "failed":
            context.testFailed = True
    print()
    

def after_scenario(context, scenario):
    if 'local' not in LT_USERNAME:
        if hasattr(context, 'testFailed'):
            context.browser.execute_script("lambda-status=failed")
        else:
            context.browser.execute_script("lambda-status=passed")
    context.browser.quit()

def after_feature(context, feature):
    pass
