from behave import *
import time


@then(u'verify that profile page is loaded')
def step_impl(context):
    assert context.profile_page.is_profile_page_displayed()


@when(u'opens basic information')
def step_impl(context):
    context.profile_page.open_basic_information()


@when(u'change language as "{language}"')
def step_impl(context, language):
    context.profile_page.set_language(language)


@when(u'save the profile page')
def step_impl(context):
    time.sleep(5)
    context.profile_page.save_page()
    context.profile_page.confirm_profile_updated()


@then(u'verify that header is appearing in Español')
def step_impl(context):
    information_basic_header = context.profile_page.get_information_basic_header_name()
    assert information_basic_header == "Información básica"


@then(u'verify that header is appearing in English')
def step_impl(context):
    information_basic_header = context.profile_page.get_information_basic_header_name()
    assert information_basic_header == "Basic Information"


@when(u'set first name as "{first_name}"')
def step_impl(context, first_name):
    context.new_first_name = first_name
    context.previous_first_name = context.profile_page.get_first_name()
    context.profile_page.set_first_name(first_name)
    time.sleep(5)
    context.profile_page.set_first_name(first_name)


@then(u'verify that first name has been changed to new name')
def step_impl(context):
    return context.profile_page.get_first_name() == context.new_first_name


@when(u'set first name as the previous name')
def step_impl(context):
    context.profile_page.set_first_name(context.previous_first_name)
    time.sleep(5)
    context.profile_page.set_first_name(context.previous_first_name)


@when(u'set last name as "{last_name}"')
def step_impl(context, last_name):
    context.new_last_name = last_name
    context.previous_last_name = context.profile_page.get_last_name()
    context.profile_page.set_last_name(last_name)
    time.sleep(5)
    context.profile_page.set_last_name(last_name)


@then(u'verify that last name has been changed to new name')
def step_impl(context):
    return context.profile_page.get_last_name() == context.new_last_name


@when(u'set last name as the previous name')
def step_impl(context):
    context.profile_page.set_last_name(context.previous_last_name)
    time.sleep(5)
    context.profile_page.set_last_name(context.previous_last_name)


@when(u'set gender as "{gender}"')
def step_impl(context, gender):
    context.new_gender = gender
    context.previous_gender = context.profile_page.get_gender()
    context.profile_page.set_gender(gender)


@then(u'verify that gender has been changed to new one')
def step_impl(context):
    return context.profile_page.get_gender() == context.new_gender


@when(u'set gender as the previous name')
def step_impl(context):
    context.profile_page.set_gender(context.previous_gender)


@when(u'set date of birth as "{date_of_birth}"')
def step_impl(context, date_of_birth):
    context.new_date_of_birth = date_of_birth
    context.previous_date_of_birth = context.profile_page.get_date_of_birth()
    context.profile_page.set_date_of_birth(date_of_birth)
    time.sleep(5)
    context.profile_page.set_date_of_birth(date_of_birth)


@then(u'verify that date of birth has been changed to new one')
def step_impl(context):
    return context.profile_page.get_date_of_birth() == context.new_date_of_birth


@when(u'set date of birth as the previous value')
def step_impl(context):
    context.profile_page.set_date_of_birth(context.previous_date_of_birth)
    time.sleep(5)
    context.profile_page.set_date_of_birth(context.previous_date_of_birth)


@when(u'set ethnicity as "{ethnicity}"')
def step_impl(context, ethnicity):
    context.new_ethnicity = ethnicity
    context.previous_ethnicity = context.profile_page.get_ethnicity()
    context.profile_page.set_ethnicity(ethnicity)
    time.sleep(5)
    context.profile_page.set_ethnicity(ethnicity)


@then(u'verify that ethnicity has been changed to new one')
def step_impl(context):
    return context.profile_page.get_ethnicity() == context.new_ethnicity


@when(u'set ethnicity as the previous value')
def step_impl(context):
    context.profile_page.set_ethnicity(context.previous_ethnicity)
    time.sleep(5)
    context.profile_page.set_ethnicity(context.previous_ethnicity)


@when(u'set race as "{race}"')
def step_impl(context, race):
    context.new_race = race
    context.previous_race = context.profile_page.get_race()
    context.profile_page.set_race(race)
    time.sleep(5)
    context.profile_page.set_race(race)


@then(u'verify that race has been changed to new one')
def step_impl(context):
    return context.profile_page.get_race() == context.new_race


@when(u'set race as the previous value')
def step_impl(context):
    context.profile_page.set_race(context.previous_race)
    time.sleep(5)
    context.profile_page.set_race(context.previous_race)


@when(u'opens household information')
def step_impl(context):
    context.profile_page.open_household_information()


@then(u'verify user have current household members')
def step_impl(context):
    assert context.profile_page.get_household_members() > 0


@when(u'add a household member')
def step_impl(context):
    context.profile_page.add_household_member()


@when(u'set household first name as "{fname}"')
def step_impl(context, fname):
    context.profile_page.set_household_first_name(fname)


@when(u'set household last name as "{lname}"')
def step_impl(context, lname):
    context.profile_page.set_household_last_name(lname)


@when(u'set household relationship as "{relationship}"')
def step_impl(context, relationship):
    context.profile_page.set_household_relationship(relationship)


@when(u'set household date of birth as "{dob}"')
def step_impl(context, dob):
    context.profile_page.set_household_dob(dob)


@when(u'save the household member')
def step_impl(context):
    context.profile_page.save_page()


@then(u'verify that household member is added with first name as "{fname}"')
def step_impl(context, fname):
    assert context.profile_page.check_presence_of_household_fname(fname)


@when(u'open the household member with first name "{fname}"')
def step_impl(context, fname):
    context.profile_page.open_household_member_with_fname(fname)


@when(u'delete the household member')
def step_impl(context):
    context.profile_page.delete_household_member()


@when(u'confirm the delete confirmation window')
def step_impl(context):
    context.profile_page.delete_confirmation_household_member()


@then(u'verify that delete success window is displayed and close')
def step_impl(context):
    assert context.profile_page.check_delete_household_confirmation_message()
    context.profile_page.close_confirmation_message()


@then(u'verify that household member with first name "{fname}" is deleted')
def step_impl(context, fname):
    assert context.profile_page.check_presence_of_household_fname(fname) == False


@then(u'verify that edit success window is displayed and close')
def step_impl(context):
    assert context.profile_page.check_edit_household_confirmation_message()
    context.profile_page.close_confirmation_message()


@then(u'verify household first name is "{fname}"')
def step_impl(context, fname):
    context.profile_page.verify_first_name_of_household(fname)


@then(u'verify household last name is "{lname}"')
def step_impl(context, lname):
    context.profile_page.verify_last_name_of_household(lname)


@then(u'verify household relationship is "{relationship}"')
def step_impl(context, relationship):
    context.profile_page.verify_relationship_of_household(relationship)


@then(u'verify household date of birth is "{dob}"')
def step_impl(context, dob):
    context.profile_page.verify_dob_of_household(dob)


@when(u'opens contact information')
def step_impl(context):
    context.profile_page.open_contact_information()


# @when(u'add a new email')
# def step_impl(context):
#     context.profile_page.add_new_email()

# @when(u'fetch a temp email id')
# def step_impl(context):
#     context.profile_page.fetch_a_temp_email()

# @when(u'enter the fetched email id and send code')
# def step_impl(context):
#     context.profile_page.set_temp_email_address()
#     context.profile_page.send_for_code()

# @when(u'get the code from the temp email id and delete it')
# def step_impl(context):
#     context.profile_page.fetch_email_code()

# @when(u'enter the code and submit')
# def step_impl(context):
#     pass

# @when(u'if the email is used in other account pair it')
# def step_impl(context):
#     pass

# @then(u'verify that the temp email id is added')
# def step_impl(context):
#     pass

# @when(u'delete the temp email id')
# def step_impl(context):
#     pass

# @then(u'temp email id is deleted')
# def step_impl(context):
#     pass

@when(u'opens address')
def step_impl(context):
    context.profile_page.open_address()


@when(u'add a new address')
def step_impl(context):
    context.profile_page.add_address()


@when(u'set address1 as "{add1}"')
def step_impl(context, add1):
    context.profile_page.add_address1(add1)


@when(u'set address2 as "{add2}"')
def step_impl(context, add2):
    context.profile_page.add_address2(add2)


@when(u'set city as "{city}"')
def step_impl(context, city):
    context.profile_page.add_city(city)


@when(u'set state as "{state}"')
def step_impl(context, state):
    context.profile_page.add_state(state)


@when(u'set zipcode as "{zip}"')
def step_impl(context, zip):
    context.profile_page.add_zip(zip)


@when(u'save the address')
def step_impl(context):
    context.profile_page.save_page()


@then(u'verify the address is added successfully')
def step_impl(context):
    context.profile_page.verify_recently_added_address()


@then(u'verify the address is not primary if another address is already present')
def step_impl(context):
    context.profile_page.verify_address_primary_status()


@when(u'user deletes the recently added address')
def step_impl(context):
    context.profile_page.delete_last_address()


@then(u'verify that address is deleted')
def step_impl(context):
    context.profile_page.verify_recently_added_address_deleted()


@when(u'user edit the recently added address')
def step_impl(context):
    context.profile_page.edit_last_address()


@then(u'verify the address is added successfully with address1 as "{add1}"')
def step_impl(context, add1):
    context.profile_page.verify_address_added(add1)


@when(u'user deletes the added address with address1 as "{add1}"')
def step_impl(context, add1):
    context.profile_page.delete_address(add1)


@then(u'verify the address is deleted with address1 as "{add1}"')
def step_impl(context, add1):
    context.profile_page.verify_address_deleted(add1)


@when(u'user set the address with address1 as "{add1}" as primary address')
def step_impl(context, add1):
    context.profile_page.set_address_as_primary(add1)


@then(u'verify the address with address1 as "{add1}" is set as primary address')
def step_impl(context, add1):
    context.profile_page.verify_address_primary(add1)


@when(u'user set another address other than address with address1 as "{add1}" as primary address')
def step_impl(context, add1):
    context.profile_page.set_other_address_as_primary(add1)
