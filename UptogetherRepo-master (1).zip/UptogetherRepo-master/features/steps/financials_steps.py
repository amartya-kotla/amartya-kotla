from behave import *

@then(u'verify that financials page is loaded')
def step_impl(context):
    assert context.financials_page.is_profile_page_displayed()